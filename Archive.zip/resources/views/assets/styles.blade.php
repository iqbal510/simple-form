<style type="text/css">
	.error{
		display: none;
		color: red;
	}
</style>