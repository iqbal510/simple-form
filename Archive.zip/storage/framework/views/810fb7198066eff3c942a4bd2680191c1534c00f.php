<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required Meta Tags -->

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/favicon.ico')); ?>" type="image/x-icon">
    <!-- CSS Files -->
    <?php echo $__env->make('assets/styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>
    <!-- Preloader Starts -->
    <div class="preloader">
        <div class="spinner"></div>
    </div>
    <!-- Preloader End -->

    <!-- Header Area Starts -->
    <?php echo $__env->make('sections/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header Area End -->

    

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Area Starts -->
    <?php echo $__env->make('sections/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Area End -->

    <?php echo $__env->make('assets/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/layout.blade.php ENDPATH**/ ?>