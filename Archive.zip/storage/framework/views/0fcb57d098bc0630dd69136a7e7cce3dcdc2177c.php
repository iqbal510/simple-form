<?php if(count($data)): ?>
<h2>Total data</h2>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Amount</th>
      <th scope="col">Buyer</th>
      <th scope="col">Receipt id</th>
      <th scope="col">Items</th>
      <th scope="col">Buyer email</th>
      <th scope="col">Buyer ip</th>
      <th scope="col">Note</th>
      <th scope="col">City</th>
      <th scope="col">Phone</th>
      <th scope="col">Entry at</th>
      <th scope="col">Entry by</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $single_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($key+1); ?></th>
      <td><?php echo e($single_data->amount); ?></td>
      <td><?php echo e($single_data->buyer); ?></td>
      <td><?php echo e($single_data->receipt_id); ?></td>
      <td>
        <?php $__currentLoopData = json_decode($single_data->items); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          Item <?php echo e($key+1); ?>. <?php echo e($item); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
      <td><?php echo e($single_data->buyer_email); ?></td>
      <td><?php echo e($single_data->buyer_ip); ?></td>
      <td><?php echo e($single_data->note); ?></td>
      <td><?php echo e($single_data->city); ?></td>
      <td><?php echo e($single_data->phone); ?></td>
      <td><?php echo e($single_data->entry_at); ?></td>
      <td><?php echo e($single_data->entry_by); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<?php else: ?>
<p>No data found</p>
<?php endif; ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/data.blade.php ENDPATH**/ ?>