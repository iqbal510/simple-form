<style type="text/css">
	.error{
		display: none;
		color: red;
	}
</style><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/assets/styles.blade.php ENDPATH**/ ?>