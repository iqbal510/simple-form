<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/"><?php echo e(env('APP_NAME')); ?></a>
    </div>
    <ul class="nav navbar-nav">
      <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a href="/">Home</a></li>
      <li class="<?php echo e(Request::is('new-form') ? 'active' : ''); ?>"><a href="<?php echo e(route('newform')); ?>">Form</a></li>
      <li class="<?php echo e(Request::is('forms') ? 'active' : ''); ?>"><a href="<?php echo e(route('forms.index')); ?>">All submission</a></li>
    </ul>
  </div>
</nav><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/navbar.blade.php ENDPATH**/ ?>